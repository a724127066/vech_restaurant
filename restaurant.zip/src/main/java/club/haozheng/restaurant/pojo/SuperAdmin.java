package club.haozheng.restaurant.pojo;








public class SuperAdmin {





}
